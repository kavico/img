<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

    </div>
</div><!-- end #body -->

<footer id="footer">
    <div class="container">
        &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 主题:<a target="_blank" href="https://minirizhi.com">BBSONE</a>. <?php echo '耗时:',timer_stop(), 's';?> 
<?php $this->options->tongji(); ?>
</footer><!-- end #footer -->
    </div>
<?php if ($this->options->prism): ?><script src="<?php $this->options->themeUrl('/js/prism.min.js'); ?>"></script>
<script type="text/javascript">var pres = document.getElementsByTagName('pre'); for (var i = 0; i < pres.length; i++) { if (pres[i].getElementsByTagName('code').length > 0) pres[i].className  = 'language-php';document.getElementsByTagName('code').className = 'language-php'; }</script><?php endif; ?>

<?php if ($this->options->imgbox): ?>
<link rel="stylesheet" href="//cdn.staticfile.org/fancybox/3.5.2/jquery.fancybox.min.css">
<script src="//cdn.staticfile.org/fancybox/3.5.2/jquery.fancybox.min.js"></script>
<script>$('[data-fancybox="gallery"]').fancybox({ buttons: ["zoom",/*"share",*/"slideShow","fullScreen",/*"download",*/"thumbs","close"],lang: "cn",i18n: { cn: { CLOSE: "关闭", NEXT: "下一张", PREV: "上一张", ERROR: "无法加载图片！ <br/> 请稍后再试……", PLAY_START: "开始预览", PLAY_STOP: "停止预览", FULL_SCREEN: "全屏", THUMBS: "缩略图", DOWNLOAD: "下载", SHARE: "分享", ZOOM: "放大" } },slideShow: { autoStart: false,speed: 3000 }, });</script><?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
<?php if ($this->options->compressHtml): $html_source = ob_get_contents(); ob_clean(); print compressHtml($html_source); ob_end_flush(); endif; ?>