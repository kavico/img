<?php
/**
 * 简洁清爽大气的模板
 * 
 * @package BBSONE
 * @author 迷你日志
 * @version 1.1
 * @link https://minirizhi.com
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<div id="mainbody">
<?php if ($this->options->picboxshow): ?>
<script src="<?php $this->options->themeUrl('/js/slide.min.js'); ?>"></script>
<div id="picbox">
        <div class="ck-slide">
        <ul class="ck-slide-wrapper">
            <?php $this->widget('Widget_Archive@indexfocus', 'pageSize=5&type=tag', 'slug=focus')->to($indexfocus); ?><?php while($indexfocus->next()): ?>
            <li><a href="<?php $indexfocus->permalink(); ?>" title="<?php $indexfocus->title() ?>"><img src="<?php echo img_postthumb($indexfocus->cid); ?>" alt="<?php $indexfocus->title() ?>" /></a></li>
            <?php endwhile; ?>
        </ul>
        <a href="javascript:;" class="ctrl-slide ck-prev">上一张</a>
        <a href="javascript:;" class="ctrl-slide ck-next">下一张</a>
        <div class="ck-slidebox">
            <div class="slideWrap">
                <ul class="dot-wrap">
                    <li class="current"><em>1</em></li>
                    <li><em>2</em></li>
                    <li><em>3</em></li>
                    <li><em>4</em></li>
                    <li><em>5</em></li>
                </ul>
            </div>
        </div>
    </div>
    <script>
        $('.ck-slide').ckSlide({
            autoPlay:true
            /*dir:"x"*/
        });
    </script>
</div>
<?php endif; ?>
<div id="main">
<div id="mainmenu">
<div class="mainheader"><li class="currenttab"><a href="/">最新</a></li></div>
<div class="mainbody">
					<?php $this->widget('Widget_Metas_Category_List')->to($category); ?>
                    <?php while($category->next()): ?>
                    <li><a <?php if ($this->is('post')): ?><?php if ($this->category == $category->slug): ?> class="current"<?php endif; ?><?php else: ?><?php if ($this->is('category', $category->slug)): ?> class="current"<?php endif; ?><?php endif; ?> href="<?php $category->permalink(); ?>"><?php $category->name(); ?></a></a></li>
                    <?php endwhile; ?>
</div>
</div>
	<?php while($this->next()): ?>
        <article class="post">
			<h2 class="post-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
			<ul class="posts-meta">
			    <li><a href="<?php $this->author->permalink(); ?>"><?php $this->author(); ?></a></li>
			    <li><?php $this->category(','); ?></li>
				<li><time><?php $this->dateword('Y-m-d'); ?></time></li>
				<li><?php get_post_view($this) ?> 次点击</li>
				<li class="right"><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('0 回复', '1 回复', '%d 回复'); ?></a></li>
			</ul>
            <div class="clearfix"></div>
        </article>
	<?php endwhile; ?>

    <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
</div><!-- end #main-->
</div>
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>
