<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="secondary">
    <?php if ($this->is('author')): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('作者信息'); ?></h2>
        <p><?php $this->author->gravatar(80); ?></p>
        <p><?php $this->author() ?></p>
        <p><a href="<?php $this->author('url'); ?>" target="_blank"><?php $this->author('url'); ?></a></p>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowTag', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('热门话题'); ?></h2>
    <div class="widgetbody center">
    <?php Typecho_Widget::widget('Widget_Metas_Tag_Cloud', 'ignoreZeroCount=1&limit=15')->to($tags); ?>
	<?php if($tags->have()): ?>
    		<?php while ($tags->next()): ?>
   		 <a class="tagcloud" href="<?php $tags->permalink();?>" title="<?php $tags->name(); ?>">
         <?php $tags->name(); ?></a> 
    <?php endwhile; ?>
    <?php endif; ?>
    </div>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowHot', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('热评帖子'); ?></h2>
        <ul class="widget-list">
		<?php rmcp(730,10);?>
        </ul>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowNew', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('最新帖子'); ?></h2>
        <ul class="widget-list">
            <?php $this->widget('Widget_Contents_Post_Recent')
            ->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
        </ul>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowComment', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('最新回复'); ?></h2>
        <ul class="widget-list-comments">
        <?php $this->widget('Widget_Comments_Recent','ignoreAuthor=true')->to($comments); ?>
        <?php while($comments->next()): ?>
            <li><a href="<?php $comments->permalink(); ?>" title="<?php $comments->excerpt(35, '...'); ?>"><?php $comments->author(false); ?></a>: <?php $comments->excerpt(35, '...'); ?></li>
        <?php endwhile; ?>
        </ul>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowArchive', $this->options->sidebarBlock)): ?>
       <section class="widget">
		<h2 class="widget-title"><?php _e('帖子归档'); ?></h2>
    <div class="widgetbody">
           <select name="archive-dropdown" onchange="location.href=this.options[this.selectedIndex].value;">
             <option>请选择月份,查看历史归档帖子</option> 
                <?php $this->widget('Widget_Contents_Post_Date', 'type=month&format=Y-m') 
->parse('<option value="{permalink}">{date}</option>'); ?> 
            </select>
    </div>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowNew', $this->options->sidebarBlock)): ?>
	<section class="widget">
		<h2 class="widget-title"><?php _e('链接信息'); ?></h2>
        <ul class="widget-list">
            <?php $this->options->links(); ?>
<?php Typecho_Widget::widget('Widget_Stat')->to($stat); ?>
<li><a>帖子总数：<?php $stat->publishedPostsNum() ?>篇</a></li>
<li><a>主题总数：<?php $stat->categoriesNum() ?>个</a></li>
<li><a>回复总数：<?php $stat->publishedCommentsNum() ?>条</a></li>
        </ul>
	</section>
    <?php endif; ?>

</div><!-- end #sidebar -->