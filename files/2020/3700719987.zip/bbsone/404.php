<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="mainbody">
    <div id="main">
	<div id="mainmenu">
<div class="mainheader"><li class="currenttab">页面没找到</li></div>
</div>

            <article class="errorpage">
                <img src="<?php $this->options->themeUrl('/img/404.png'); ?>" alt="404">
            </article>

    </div><!-- end #main -->
    </div>
	<?php $this->need('sidebar.php'); ?>
    </div>
</div><!-- end #body -->

<footer id="footer">
    <div class="container">
        &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 主题:<a target="_blank" href="https://minirizhi.com">BBSONE</a>. <?php echo '耗时:',timer_stop(), 's';?> 
<?php $this->options->tongji(); ?>
</footer><!-- end #footer -->
    </div>

<?php if ($this->options->prism): ?><script src="<?php $this->options->themeUrl('/js/prism.min.js'); ?>"></script>
<script type="text/javascript">var pres = document.getElementsByTagName('pre'); for (var i = 0; i < pres.length; i++) { if (pres[i].getElementsByTagName('code').length > 0) pres[i].className  = 'language-php';document.getElementsByTagName('code').className = 'language-php'; }</script><?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
