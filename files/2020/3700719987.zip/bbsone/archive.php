<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="mainbody">
    <div id="main">
	<div id="mainmenu">
<div class="mainheader"><li class="currenttab"><?php $this->archiveTitle(array(
            'category'  =>  _t('主题<span> %s </span>下的帖子'),
            'tag'       =>  _t('话题<span> %s </span>下的帖子'),
            'search'    =>  _t('包含关键字<span> %s </span>的帖子'),
            'date'      =>  _t('在<span> %s </span>发布的帖子'),
            'author'    =>  _t('<span>%s </span>发布的帖子')
        ), '', ''); ?></li></div>
<div class="mainbody">
					<?php $this->widget('Widget_Metas_Category_List')->to($category); ?>
                    <?php while($category->next()): ?>
                    <li><a <?php if ($this->is('post')): ?><?php if ($this->category == $category->slug): ?> class="current"<?php endif; ?><?php else: ?><?php if ($this->is('category', $category->slug)): ?> class="current"<?php endif; ?><?php endif; ?> href="<?php $category->permalink(); ?>"><?php $category->name(); ?></a></a></li>
                    <?php endwhile; ?>
</div>
</div>

        <?php if ($this->have()): ?>

    	<?php while($this->next()): ?>
            <article class="post">
    			<h2 class="post-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
			<ul class="posts-meta">
			    <li><a href="<?php $this->author->permalink(); ?>"><?php $this->author(); ?></a></li>
			    <li><?php $this->category(','); ?></li>
				<li><time><?php $this->dateword('Y-m-d'); ?></time></li>
				<li><?php get_post_view($this) ?> 次点击</li>
				<li class="right"><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('0 回复', '1 回复', '%d 回复'); ?></a></li>
			</ul>
                <div class="clearfix"></div>
    		</article>
    	<?php endwhile; ?>
        <?php endif; ?>

        <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
    </div><!-- end #main -->
    </div>
	<?php $this->need('sidebar.php'); ?>
	<?php $this->need('footer.php'); ?>
