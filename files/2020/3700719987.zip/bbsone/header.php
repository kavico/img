<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title><?php if($this->_currentPage>1) echo '第 '.$this->_currentPage.' 页 - '; ?><?php $this->archiveTitle(array(
            'category'  =>  _t('主题 %s 下的帖子'),
            'tag'       =>  _t('话题 %s 下的帖子'),
            'search'    =>  _t('包含关键字 %s 的帖子'),
            'date'      =>  _t('在 %s 发布的帖子'),
            'author'    =>  _t('%s 发布的帖子')
        ), '', ' - '); ?><?php if ($this->is('post')) $this->category(',', false);?><?php if ($this->is('post')) echo ' - ';?><?php $this->options->title(); ?><?php if ($this->is('index')) echo ' - '; ?><?php if ($this->is('index')) $this->options->description() ?></title>

    <!-- 使用url函数转换相关路径 -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('/css/style.min.css'); ?>">
    <?php if ($this->options->picboxshow): ?><link rel="stylesheet" href="<?php $this->options->themeUrl('/css/slide.min.css'); ?>"><?php endif; ?>
	<?php if ($this->options->prism): ?><link rel="stylesheet" href="<?php $this->options->themeUrl('/css/prism.min.css'); ?>"><?php endif; ?>
	<?php if ($this->options->picboxshow || $this->options->imgbox): ?><script src="//cdn.staticfile.org/jquery/2.1.4/jquery.min.js"></script><?php endif; ?>
    <?php if ($this->options->icoUrl): ?><link rel='icon' href='<?php $this->options->icoUrl() ?>' type='image/x-icon' /><?php endif; ?>
    <!-- 通过自有函数输出HTML头部信息 -->
    <?php $this->header("generator=&template=&pingback=&wlw=&xmlrpc=&rss1=&atom=&rss2=/feed"); ?>
</head>
<body>

<header id="header">
    <div class="container">
         <div id="logo">
            <?php if ($this->options->logoUrl): ?>
                <a class="logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>" />
                </a>
            <?php else: ?>
                <a class="logo" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>
            <?php endif; ?>
         </div>
			<button id="menubutton" disable="enable" onclick="var qr = document.getElementById('menu'); if (qr.style.display === 'inline-block') {qr.style.display='none';} else {qr.style.display='inline-block'}">
                <span><i></i><i></i><i></i></span></button>
            <div id="menu">
                <nav id="nav-menu" role="navigation">
                    <li><a <?php if($this->is('index')): ?> class="current"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a><li>
                    <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
                    <?php while($pages->next()): ?>
                    <li><a <?php if($this->is('page', $pages->slug)): ?> class="current"<?php endif; ?> href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a></li>
                    <?php endwhile; ?>
					<li><form id="search" method="post" action="./" role="search">
					<input type="text" name="s" class="text" placeholder="<?php _e('输入关键字搜索'); ?>" required/>
					<button type="submit" class="submit"><?php _e('搜索'); ?></button>
					</form></li>
					<div class="clearfix"></div>
                </nav>
            </div>
    </div>
</header>

<div id="body">
    <div class="container">
