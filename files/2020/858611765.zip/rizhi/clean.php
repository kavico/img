<?php
/**
 * 清空文件缓存
 */
function delcache($cache)
{
    $fh = opendir($cache);
    while (($file = readdir($fh)) !== false) {
            if($file!=".."&&$file!=".") {
                if(is_dir($cache."/".$file)) {
                    delcache($cache."/".$file);
                } else {
                    unlink($cache."/".$file);
                }
            }
        }
    closedir($fh);
}
delcache(dirname(__FILE__).'/cache');
echo('<html>
<head>
<meta http-equiv=Content-Type content="text/html;charset=utf-8">
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>CLEAN CACHE</title>
<style>
@media (max-width:4096px){h2 {margin:30px;font-size:1em;text-align:center;}}
</style>
</head>
<body>
<h2>Cache is cleard !</h2>
<h2><a href="javascript:self.close()" >CLOSE</a></h2>
</div>
</body>
</html>');