<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="main">
    <article class="post">
			<h2 class="post-title center"><?php $this->title() ?></h2>
			<ul class="meta center">
				<li><time><?php $this->date('Y-m-d'); ?></time></li> 
				<li><?php $this->category(','); ?></li> 
				<li><a><?php get_post_view($this) ?></a> 阅读</li> 
				<li><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 评论', '%d 评论'); ?></a></li>
			</ul>
<?php if ($this->options->postcache): ?><?php StartCache(mb_substr(md5($_SERVER["REQUEST_URI"]),0,16));if(!Have_Cached(mb_substr(md5($_SERVER["REQUEST_URI"]),0,16))){ ?>
        <div class="post-content">
            <?php if ($this->options->imgbox && $this->options->lazyload): ?>
            <?php echo parseContent($this); ?>
			<?php elseif ($this->options->imgbox): ?>
			<?php echo parseContentbox($this); ?>
			<?php elseif ($this->options->lazyload): ?>
			<?php echo parseContentlazy($this); ?>
			<?php else: ?>
			<?php echo parseContentbox($this); ?>
			<?php endif; ?>
        </div>
<?php if ($this->options->qcode): ?>
<div class="reward">
    <button id="rewardButton" disable="enable" onclick="var qr = document.getElementById('QR'); if (qr.style.display === 'none') {qr.style.display='block';} else {qr.style.display='none'}">
        <span>扫码</span></button>
    <div id="QR" style="display: none;">
        <?php if ($this->options->codewx): ?>
        <div id="wechat" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="wechat_qr" src="<?php $this->options->icoUrl() ?>" alt="微信打赏"></a>
            <p>微信打赏</p>
        </div>
		<?php endif; ?>
		<?php if ($this->options->codeali): ?>
        <div id="alipay" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="alipay_qr" src="<?php $this->options->codeali() ?>" alt="支付宝打赏"></a>
            <p>支付宝打赏</p>
        </div>
		<?php endif; ?>
		<?php if ($this->options->codemp): ?>
        <div id="qcode" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="qcode_qr" src="<?php $this->options->codemp() ?>" alt="微信公众号"></a>
            <p>微信公众号</p>
        </div>
		<?php endif; ?>
        <div id="qrcode" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="qrcode_qr" src="<?php $this->options->themeUrl('/img/qrcode.php'); ?>?text=<?php $this->permalink() ?>&size=256" alt="网页二维码"></a>
            <p>网页二维码</p>
        </div>
    </div>
</div><?php endif; ?>
        <ul>
        <li>上一篇: <?php $this->thePrev('%s','没有了'); ?></li>
        <li>下一篇: <?php $this->theNext('%s','没有了'); ?></li>
        </ul>
        <p class="tags"><?php _e('标签: '); ?><?php $this->tags(', ', true, '无标签'); ?><br><?php _e('本文最后更新于: '); ?><?php echo date('Y-m-d H:i:s',$this->modified); ?></p>
    </article>
    <h2 class="more"><?php _e('猜您喜欢'); ?></h2>
    <ul class="widget-list">
        <?php $this->related(5)->to($relatedPosts); ?>
        <?php if ($relatedPosts->have()): ?>
        <?php while ($relatedPosts->next()): ?>
        <li><a href="<?php $relatedPosts->permalink(); ?>" title="<?php $relatedPosts->title(); ?>"><?php $relatedPosts->title(); ?></a></li>
        <?php endwhile; ?>
        <?php else : ?>
        <?php theme_random_posts();?>
        <?php endif; ?>
    </ul>
<?php } EndCache(mb_substr(md5($_SERVER["REQUEST_URI"]),0,16));?>
<?php else: ?>
        <div class="post-content">
            <?php if ($this->options->imgbox && $this->options->lazyload): ?>
            <?php echo parseContent($this); ?>
			<?php elseif ($this->options->imgbox): ?>
			<?php echo parseContentbox($this); ?>
			<?php elseif ($this->options->lazyload): ?>
			<?php echo parseContentlazy($this); ?>
			<?php else: ?>
			<?php echo parseContentbox($this); ?>
			<?php endif; ?>
        </div>
<?php if ($this->options->qcode): ?>
<div class="reward">
    <button id="rewardButton" disable="enable" onclick="var qr = document.getElementById('QR'); if (qr.style.display === 'none') {qr.style.display='block';} else {qr.style.display='none'}">
        <span>扫码</span></button>
    <div id="QR" style="display: none;">
        <?php if ($this->options->codewx): ?>
        <div id="wechat" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="wechat_qr" src="<?php $this->options->icoUrl() ?>" alt="微信打赏"></a>
            <p>微信打赏</p>
        </div>
		<?php endif; ?>
		<?php if ($this->options->codeali): ?>
        <div id="alipay" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="alipay_qr" src="<?php $this->options->codeali() ?>" alt="支付宝打赏"></a>
            <p>支付宝打赏</p>
        </div>
		<?php endif; ?>
		<?php if ($this->options->codemp): ?>
        <div id="qcode" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="qcode_qr" src="<?php $this->options->codemp() ?>" alt="微信公众号"></a>
            <p>微信公众号</p>
        </div>
		<?php endif; ?>
        <div id="qrcode" style="display: inline-block">
            <a class="fancybox" rel="group">
                <img id="qrcode_qr" src="<?php $this->options->themeUrl('/img/qrcode.php'); ?>?text=<?php $this->permalink() ?>&size=256" alt="网页二维码"></a>
            <p>网页二维码</p>
        </div>
    </div>
</div><?php endif; ?>
        <ul>
        <li>上一篇: <?php $this->thePrev('%s','没有了'); ?></li>
        <li>下一篇: <?php $this->theNext('%s','没有了'); ?></li>
        </ul>
        <p class="tags"><?php _e('标签: '); ?><?php $this->tags(', ', true, '无标签'); ?><br><?php _e('本文最后更新于: '); ?><?php echo date('Y-m-d H:i:s',$this->modified); ?></p>
    </article>
    <h2 class="more"><?php _e('猜您喜欢'); ?></h2>
    <ul class="widget-list">
        <?php $this->related(5)->to($relatedPosts); ?>
        <?php if ($relatedPosts->have()): ?>
        <?php while ($relatedPosts->next()): ?>
        <li><a href="<?php $relatedPosts->permalink(); ?>" title="<?php $relatedPosts->title(); ?>"><?php $relatedPosts->title(); ?></a></li>
        <?php endwhile; ?>
        <?php else : ?>
        <?php theme_random_posts();?>
        <?php endif; ?>
    </ul>
	<?php endif; ?>
    <?php $this->need('comments.php'); ?>
</div>
<?php $this->need('footer.php'); ?>
