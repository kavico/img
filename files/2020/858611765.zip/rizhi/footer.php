<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
    <footer id="footer">
    <p><?php $this->options->links(); ?></p>
            &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 主题:<a target="_blank" href="https://minirizhi.com">迷你日志</a>
    <?php $this->options->tongji(); ?>
    </footer>
</div>

<div id="cornertool"><ul><?php if ($this->options->top): ?><li id="top" class="hidden"></li><?php endif; ?><?php if ($this->options->dark): ?><li id="DarkModeButton" onclick = "switchNightMode()" class="">◐</li><?php endif; ?></ul></div>
<?php $this->footer(); ?>
<?php if ($this->options->dark): ?><script src="<?php $this->options->themeUrl('/js/rizhi.js'); ?>"></script><?php endif; ?>
<?php if ($this->options->pjax || $this->options->imgbox || $this->options->lazyload): ?><script src="//cdn.staticfile.org/jquery/2.1.4/jquery.min.js"></script><?php endif; ?>
<?php if ($this->options->pjax): ?><script src="//cdn.staticfile.org/jquery.pjax/1.9.6/jquery.pjax.min.js"></script><?php endif; ?>
<?php if ($this->options->lazyload): ?><script src="//cdn.staticfile.org/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>
<script>$(function() {$("img").lazyload({effect: "fadeIn", threshold: 200, failurelimit: 2});});</script><?php endif; ?>
<?php if ($this->options->imgbox): ?><script src="//cdn.staticfile.org/fancybox/3.5.2/jquery.fancybox.min.js"></script>
<script>$('[data-fancybox="gallery"]').fancybox({ buttons: ["zoom",/*"share",*/"slideShow","fullScreen",/*"download",*/"thumbs","close"],lang: "cn",i18n: { cn: { CLOSE: "关闭", NEXT: "下一张", PREV: "上一张", ERROR: "无法加载图片！ <br/> 请稍后再试……", PLAY_START: "开始预览", PLAY_STOP: "停止预览", FULL_SCREEN: "全屏", THUMBS: "缩略图", DOWNLOAD: "下载", SHARE: "分享", ZOOM: "放大" } },slideShow: { autoStart: false,speed: 3000 }, });</script><?php endif; ?>
<?php if ($this->options->prism): ?><script src="<?php $this->options->themeUrl('/js/prism.min.js'); ?>"></script>
<script type="text/javascript">var pres = document.getElementsByTagName('pre'); for (var i = 0; i < pres.length; i++) { if (pres[i].getElementsByTagName('code').length > 0) pres[i].className  = 'language-php';document.getElementsByTagName('code').className = 'language-php'; }</script><?php endif; ?>

<?php if ($this->options->top): ?><script>window.onscroll=function(){var a=document.documentElement.scrollTop||document.body.scrollTop;var b=document.getElementById("top");if(a>=200){b.removeAttribute("class")}else{b.setAttribute("class","hidden")}b.onclick=function totop(){var a=document.documentElement.scrollTop||document.body.scrollTop;if(a>0){requestAnimationFrame(totop);window.scrollTo(0,a-(a/5))}else{cancelAnimationFrame(totop)}}};</script><?php endif; ?>

<?php if ($this->options->mulu): ?><script>var cornertool=true;function cl(){var a=document.getElementById("catalog-col"),b=document.getElementById("catalog"),c=document.getElementById("cornertool"),d;if(a&&!b){if(c){c=c.getElementsByTagName("ul")[0];d=document.createElement("li");d.setAttribute("id","catalog");d.setAttribute("onclick","Catalogswith()");d.appendChild(document.createElement("span"));c.appendChild(d)}else{cornertool=false;c=document.createElement("div");c.setAttribute("id","cornertool");c.innerHTML='<ul><li id="catalog" onclick="Catalogswith()"><span></span></li></ul>';document.body.appendChild(c)}document.getElementById("catalog").className=a.className}if(!a&&b){cornertool?c.getElementsByTagName("ul")[0].removeChild(b):document.body.removeChild(c)}if(a&&b){b.className=a.className}}cl();</script><?php endif; ?>
<?php if ($this->options->pjax || $this->options->pjax && ($this->options->prism || $this->options->imgbox || $this->options->mulu || $this->options->lazyload)): ?>
<script>
$(document).pjax('a[href^="<?php Helper::options()->siteUrl()?>"]:not(a[target="_blank"], a[no-pjax])', {container: '#mainbody',fragment: '#mainbody',timeout: 10000})
.on('submit','form[id=search]',function(event){$.pjax.submit(event,{container:'#mainbody',fragment:'#mainbody',timeout:10000})})
.on('pjax:send',function(){$("#header").prepend("<div id='bar'></div>")})
.on('pjax:complete',function(){setTimeout(function(){$("#bar").remove()},300);
<?php if ($this->options->mulu): ?>var cornertool=true;function cl(){var a=document.getElementById("catalog-col"),b=document.getElementById("catalog"),c=document.getElementById("cornertool"),d;if(a&&!b){if(c){c=c.getElementsByTagName("ul")[0];d=document.createElement("li");d.setAttribute("id","catalog");d.setAttribute("onclick","Catalogswith()");d.appendChild(document.createElement("span"));c.appendChild(d)}else{cornertool=false;c=document.createElement("div");c.setAttribute("id","cornertool");c.innerHTML='<ul><li id="catalog" onclick="Catalogswith()"><span></span></li></ul>';document.body.appendChild(c)}document.getElementById("catalog").className=a.className}if(!a&&b){cornertool?c.getElementsByTagName("ul")[0].removeChild(b):document.body.removeChild(c)}if(a&&b){b.className=a.className}}cl();<?php endif; ?>
<?php if ($this->options->lazyload): ?>$("img").lazyload({effect: "fadeIn", threshold: 200, failurelimit: 2});<?php endif; ?>
<?php if ($this->options->imgbox): ?>$('[data-fancybox="gallery"]').fancybox({ buttons: ["zoom",/*"share",*/"slideShow","fullScreen",/*"download",*/"thumbs","close"],lang: "cn",i18n: { cn: { CLOSE: "关闭", NEXT: "下一张", PREV: "上一张", ERROR: "无法加载图片！ <br/> 请稍后再试……", PLAY_START: "开始预览", PLAY_STOP: "停止预览", FULL_SCREEN: "全屏", THUMBS: "缩略图", DOWNLOAD: "下载", SHARE: "分享", ZOOM: "放大" } },slideShow: { autoStart: false,speed: 3000 }, });<?php endif; ?>
<?php if ($this->options->prism): ?>if (typeof Prism !== 'undefined') {
var pres = document.getElementsByTagName('pre'); for (var i = 0; i < pres.length; i++) { if (pres[i].getElementsByTagName('code').length > 0) pres[i].className  = 'language-php';document.getElementsByTagName('code').className = 'language-php'; }
Prism.highlightAll(true,null); };<?php endif; ?>
if(typeof _hmt!=='undefined'){_hmt.push(['_trackPageview',location.pathname+location.search])};
})
</script>
<?php endif; ?>
<?php if ($this->options->banquan): ?><script>
    document.body.addEventListener('copy', function (e) {
    if (window.getSelection().toString() && window.getSelection().toString().length > 2) {
        setClipboardText(e);
        alert('商业转载请联系作者获得授权，非商业转载请注明出处哦~\n谢谢合作~(｡・`ω´･)');
    }
    }); 
    function setClipboardText(event) {
    var clipboardData = event.clipboardData || window.clipboardData;
    if (clipboardData) {
        event.preventDefault();
        var htmlData = ''
            + window.getSelection().toString()
            + '<br><br>作者：<a target="_blank" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a><br>'
            + '来源：<a target="_blank" href="<?php $this->permalink() ?>"><?php $this->title() ?></a>';
        var textData = ''
            + window.getSelection().toString()
            + '\n\n作者：<a target="_blank" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>\n'
            + '来源：<a target="_blank" href="<?php $this->permalink() ?>"><?php $this->title() ?></a>';
        clipboardData.setData('text/html', htmlData);
        clipboardData.setData('text/plain',textData);
    }
    }
</script><?php endif; ?>
</body>
</html>
<?php if ($this->options->compressHtml): $html_source = ob_get_contents(); ob_clean(); print compressHtml($html_source); ob_end_flush(); endif; ?>