<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div id="main">
<?php if ($this->options->pagecache): ?><?php StartCache(mb_substr(md5($_SERVER["REQUEST_URI"]),0,16));if(!Have_Cached(mb_substr(md5($_SERVER["REQUEST_URI"]),0,16))){ ?>
    <article class="post">
			<h2 class="post-title center"><?php $this->title() ?></h2>
        <div class="post-content">
            <?php if ($this->options->imgbox && $this->options->lazyload): ?>
            <?php echo parseContent($this); ?>
			<?php elseif ($this->options->imgbox): ?>
			<?php echo parseContentbox($this); ?>
			<?php elseif ($this->options->lazyload): ?>
			<?php echo parseContentlazy($this); ?>
			<?php else: ?>
			<?php echo parseContentbox($this); ?>
			<?php endif; ?>
        </div>
    </article>
<?php } EndCache(mb_substr(md5($_SERVER["REQUEST_URI"]),0,16));?>
<?php else: ?>
    <article class="post">
			<h2 class="post-title center"><?php $this->title() ?></h2>
        <div class="post-content">
            <?php if ($this->options->imgbox && $this->options->lazyload): ?>
            <?php echo parseContent($this); ?>
			<?php elseif ($this->options->imgbox): ?>
			<?php echo parseContentbox($this); ?>
			<?php elseif ($this->options->lazyload): ?>
			<?php echo parseContentlazy($this); ?>
			<?php else: ?>
			<?php echo parseContentbox($this); ?>
			<?php endif; ?>
        </div>
    </article>
<?php endif; ?>
    <?php $this->need('comments.php'); ?>
</div>
<?php $this->need('footer.php'); ?>
