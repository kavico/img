<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

    </div>
</div><!-- end #body -->

<footer id="footer">
    <div class="container">
        &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 主题:<a target="_blank" href="https://minirizhi.com">Biji</a>. <?php echo '耗时:',timer_stop(), 's';?> 
<?php $this->options->tongji(); ?>
</footer><!-- end #footer -->
    </div>

<div id="cornertool"><ul><?php if ($this->options->top): ?><li id="top" class="hidden"></li><script>window.onscroll=function(){var a=document.documentElement.scrollTop||document.body.scrollTop;var b=document.getElementById("top");if(a>=200){b.removeAttribute("class")}else{b.setAttribute("class","hidden")}b.onclick=function totop(){var a=document.documentElement.scrollTop||document.body.scrollTop;if(a>0){requestAnimationFrame(totop);window.scrollTo(0,a-(a/5))}else{cancelAnimationFrame(totop)}}};</script><?php endif; ?><?php if ($this->options->dark): ?><li id="DarkModeButton" onclick = "switchNightMode()" class="">◐</li><script src="<?php $this->options->themeUrl('/js/dark.min.js'); ?>"></script><?php endif; ?></ul></div>

<?php if ($this->options->instantclick): ?><script src="//cdn.staticfile.org/instantclick/3.1.0/instantclick.min.js" data-no-instant></script>
<script data-no-instant>
InstantClick.on('change', function(isInitialLoad) {
		if (isInitialLoad === false) {
			if (typeof Prism !== 'undefined') Prism.highlightAll(true,null);
			if (typeof _hmt !== 'undefined') _hmt.push(['_trackPageview', location.pathname + location.search]);
		}
	});
InstantClick.init('mousedown');</script><?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
<?php if ($this->options->compressHtml): $html_source = ob_get_contents(); ob_clean(); print compressHtml($html_source); ob_end_flush(); endif; ?>