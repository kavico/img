<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

    </div>
</div><!-- end #body -->

<footer id="footer">
    <div class="container">
        &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 主题:<a target="_blank" href="https://minirizhi.com">Mini</a>. <?php echo '耗时:',timer_stop(), 's';?> 
<?php $this->options->tongji(); ?>
</footer><!-- end #footer -->
    </div>
<?php $this->footer(); ?>
</body>
</html>
<?php if ($this->options->compressHtml): $html_source = ob_get_contents(); ob_clean(); print compressHtml($html_source); ob_end_flush(); endif; ?>