<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

        <div class="error-page">
            <h2 class="post-title">404 - <?php _e('页面没找到'); ?></h2>
            <p><?php _e('页面没找到了, 要不搜索试试: '); ?></p>
            <form method="post">
                <p><input type="text" name="s" class="text" autofocus required/></p>
                <p><button type="submit" class="submit"><?php _e('搜索'); ?></button></p>
            </form>
        </div>

    </div>
</div><!-- end #body -->

<footer id="footer">
    <div class="container">
        &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 主题:<a target="_blank" href="https://minirizhi.com">Mini</a>. <?php echo '耗时:',timer_stop(), 's';?> 
<?php $this->options->tongji(); ?>
</footer><!-- end #footer -->
    </div>
<?php $this->footer(); ?>
</body>
</html>
