<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div id="main">
    <article class="post">
        <h1><?php $this->title() ?></h1>
        <ul class="post-meta">
            <li><time><?php $this->date('Y-m-d'); ?></time></li>
            <li><?php $this->category(','); ?></li>
			<li><a><?php get_post_view($this) ?></a> 阅读</li>
            <li><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 评论', '%d 评论'); ?></a></li>
        </ul>
        <div class="post-content">
            <?php $this->content(); ?>
        </div>
        <div class="reward">
        <button id="rewardButton" disable="enable" onclick="var qr = document.getElementById('QR'); if (qr.style.display === 'none') {qr.style.display='block';} else {qr.style.display='none'}">
        <span>打赏</span></button>
        <div id="QR" style="display: none;">
        <div id="wechat" style="display: inline-block">
            <a class="fancybox" rel="group">
            <img id="wechat_qr" src="<?php $this->options->wepayUrl() ?>" alt="微信打赏"></a>
            <p>微信打赏</p>
        </div>
        <div id="alipay" style="display: inline-block">
            <a class="fancybox" rel="group">
            <img id="alipay_qr" src="<?php $this->options->alipayUrl() ?>" alt="支付宝打赏"></a>
            <p>支付宝打赏</p>
        </div>
        </div>
        </div>
        <p class="tags"><?php _e('标签: '); ?><?php $this->tags(', ', true, '无标签'); ?></p>
		<div class="post-near">
        <li class="post-left"><?php $this->thePrev('%s','没有了'); ?></li>
        <li class="post-right"><?php $this->theNext('%s','没有了'); ?></li>
        </div>
		<div class="clearfix"></div>
		<h2 id="more"><?php _e('猜您喜欢'); ?></h2>
        <div class="more-list">
        <?php $this->related(5)->to($relatedPosts); ?>
        <?php if ($relatedPosts->have()): ?>
        <?php while ($relatedPosts->next()): ?>
        <li><a href="<?php $relatedPosts->permalink(); ?>" title="<?php $relatedPosts->title(); ?>"><?php $relatedPosts->title(); ?></a></li>
        <?php endwhile; ?>
        <?php else : ?>
        <?php theme_random_posts();?>
        <?php endif; ?>
        </div>
    </article>
    <?php $this->need('comments.php'); ?>
</div><!-- end #main-->

<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>
