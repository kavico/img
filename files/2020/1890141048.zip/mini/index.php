<?php
/**
 * 简洁清爽大气的模板
 * 
 * @package Mini 
 * @author 迷你日志
 * @version 2.0
 * @link https://minirizhi.com
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<div id="main">
	<?php while($this->next()): ?>
        <article class="post">
			<h2 class="post-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
			<ul class="posts-meta">
				<li><time><?php $this->date('Y-m-d'); ?></time></li>
				<li><?php $this->category(','); ?></li>
				<li><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 评论', '%d 评论'); ?></a></li>
			</ul>
			<div class="post-thumb"><a href="<?php $this->permalink() ?>" title="<?php $this->title() ?>"><img src="<?php showThumbnail($this); ?>" alt="<?php $this->title() ?>"></a><div>
            <div class="post-excerpt">
    			<?php $this->excerpt(180); ?>
            </div>
            <div class="clearfix"></div>
        </article>
	<?php endwhile; ?>

    <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
</div><!-- end #main-->
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>
