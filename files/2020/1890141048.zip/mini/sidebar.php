<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="secondary">
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowTag', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('热门话题'); ?></h2>
    <?php Typecho_Widget::widget('Widget_Metas_Tag_Cloud', 'ignoreZeroCount=1&limit=25')->to($tags); ?>
	<?php if($tags->have()): ?>
    		<?php while ($tags->next()): ?>
   		 <a class="tagcloud" style="color:rgb(<?php echo(rand(0,255)); ?>,<?php echo(rand(0,255)); ?>,
           	<?php echo(rand(0,255)); ?>)" href="<?php $tags->permalink();?>" title="<?php $tags->name(); ?>">
         <?php $tags->name(); ?></a> 
    <?php endwhile; ?>
    <?php endif; ?>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowHot', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('热门文章'); ?></h2>
        <ul class="widget-list">
		<?php rmcp(730,10);?>
        </ul>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowNew', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('最新文章'); ?></h2>
        <ul class="widget-list">
            <?php $this->widget('Widget_Contents_Post_Recent')
            ->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
        </ul>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowComment', $this->options->sidebarBlock)): ?>
    <section class="widget">
		<h2 class="widget-title"><?php _e('最新评论'); ?></h2>
        <ul class="widget-list-comments">
        <?php $this->widget('Widget_Comments_Recent','ignoreAuthor=true')->to($comments); ?>
        <?php while($comments->next()): ?>
            <li><a href="<?php $comments->permalink(); ?>" title="<?php $comments->excerpt(35, '...'); ?>"><?php $comments->author(false); ?></a>: <?php $comments->excerpt(35, '...'); ?></li>
        <?php endwhile; ?>
        </ul>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowArchive', $this->options->sidebarBlock)): ?>
       <section class="widget">
		<h2 class="widget-title"><?php _e('文章归档'); ?></h2>
           <select name="archive-dropdown" onchange="location.href=this.options[this.selectedIndex].value;">
             <option>请选择月份,查看历史归档文章</option> 
                <?php $this->widget('Widget_Contents_Post_Date', 'type=month&format=Y-m') 
->parse('<option value="{permalink}">{date}</option>'); ?> 
            </select>
    </section>
    <?php endif; ?>
    <?php if (!empty($this->options->sidebarBlock) && in_array('ShowNew', $this->options->sidebarBlock)): ?>
	<section class="widget">
		<h2 class="widget-title"><?php _e('链接信息'); ?></h2>
        <ul class="widget-list">
            <?php $this->options->links(); ?>
            <li><a href="<?php $this->options->feedUrl(); ?>" target="_blank" title="Feed订阅"><?php _e('Feed订阅'); ?></a></li>
        </ul>
	</section>
    <?php endif; ?>

</div><!-- end #sidebar -->